import java.util.*;

class Guesser
{
	int guessNum;
	
	int guessNum()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Hey Guesser, your turn....\n Kindly mention a number...");
		guessNum = scan.nextInt();
		return guessNum;
		
	}
}
class Players
{
	int guessNum;
	int players;
	
	int getPlayersCount()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of players....");
		players = scan.nextInt();
		return players;
	}
	
	int guessNum()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Hey Players! Kindly guess the number...");
		guessNum = scan.nextInt();
		return guessNum;
		
	}
	
}

class Umpire
{
	int numFromGuesser;
	int playersCount;
	int[] numFromPlayer;

	int numberOfplayers()
	{
		Players p = new Players();
		return p.getPlayersCount();
	}
	void collectNumFromGuesser()
	{
		Guesser guesser = new Guesser();
		numFromGuesser = guesser.guessNum();
		
	}
	
	void collectNumFromPlayers()
	{
		
		Players player = new Players();
		playersCount = player.getPlayersCount();
		numFromPlayer = new int[playersCount];
		for(int i = 0; i < playersCount; i ++)
		{
			numFromPlayer[i] = player.guessNum();
			compare(numFromPlayer[i]);
			
			
		}
	
		
	}
	
	void compare(int num)
	{
		
			if(num == numFromGuesser)
			{
				System.out.println("You won the game!");
				
			}
			else if(num < numFromGuesser)
			{
				System.out.println("Oops.... guessed number is smaller than Original"
						+ " number");
			}
			else if(num > numFromGuesser)
			{
				System.out.println("Oops.... guessed number is larger than Original"
						+ " number");
			}
		
	}

	
}

public class LaunchGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("****** Welcome to Guesser game! ******");
		System.out.println("Let's begin the game......");
		
		Umpire umpire = new Umpire();
		umpire.collectNumFromGuesser();
		umpire.collectNumFromPlayers();

	}

}
